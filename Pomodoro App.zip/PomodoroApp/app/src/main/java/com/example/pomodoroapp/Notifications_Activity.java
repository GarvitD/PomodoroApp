package com.example.pomodoroapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Notifications_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);
    }
}