# PomodoroApp
An App currently in making focuses on helping people to improve  focus and increase productivity
